﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lm.Comol.Core.DomainModel.DocTemplateVers.Domain.DTO.Management
{
    public class DTO_EditPreviousVersion
    {
        public Int64 Id { get; set; }
        public DateTime? Lastmodify { get; set; }
        //...
    }
}
